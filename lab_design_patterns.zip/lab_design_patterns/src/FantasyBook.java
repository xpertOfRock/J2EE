public class FantasyBook extends Book {
    public FantasyBook() {
        setGenre("Fantasy");
    }
}