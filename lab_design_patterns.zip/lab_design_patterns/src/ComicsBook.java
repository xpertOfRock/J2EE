public class ComicsBook extends Book {
    public ComicsBook() {
        setGenre("Comics");
    }
}