
public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {
        Bookshelf bookshelf = Bookshelf.getInstance();
        BookGenerator bookGenerator = new BookGenerator();

        Book book1 = bookGenerator.createBook("fantasy");
        Book book2 = bookGenerator.createBook("comics");
        Book book3 = bookGenerator.createBook("fantasy");

        bookshelf.addBook(book1);
        bookshelf.addBook(book2);
        bookshelf.addBook(book3);

        Book book4 = bookGenerator.createBook("fantasy");
        bookshelf.addBook(book4);

        System.out.println("Books on the bookshelf:");

        bookshelf.displayBooks();

        bookshelf.removeBook(book4);

        Book book5 = bookGenerator.createBook("fantasy");
        bookshelf.addBook(book5);

        System.out.println("Books on the bookshelf:");

        bookshelf.displayBooks();

    }
}